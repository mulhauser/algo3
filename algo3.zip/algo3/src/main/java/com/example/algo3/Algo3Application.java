package com.example.algo3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Algo3Application {

	public static void main(String[] args) {

		try {

			List<String> lines = Files.readAllLines(Paths.get("input.txt"));
			char[][] tab = new char[lines.size()][lines.get(0).length()];
			List<Position> symbols = new ArrayList<>();
			for (int i = 0; i < lines.size(); i++) {
				String line = lines.get(i);
				for (int j = 0; j < line.length(); j++) {
					char str = line.charAt(j);
					if (!Character.isDigit(str) && !(str == '.')) {
						symbols.add(new Position(i, j));
					}
				}
			}
			int nbRows = tab.length;
			int nbCols = tab[0].length;

			for (Position symbol : symbols) {
				for (int i = 0; i <= 1; i++) {
					for (int j = 0; j <= 1; j++) {
						if (i==0 && j==0){
							continue;
						}
						int posXCharToCheck = symbol.getX()+i;
						int posYCharToCheck = symbol.getY()+i;
						if (posXCharToCheck>=0&&posXCharToCheck<nbRows && posYCharToCheck>=0&&posYCharToCheck<nbCols){
							if (Character.isDigit(tab[posXCharToCheck][posYCharToCheck])) {
								NumberAndPositions numPos = getNumberAndPosition(posXCharToCheck, posYCharToCheck, tab);
								
							}
						}
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static NumberAndPositions getNumberAndPosition(int x, int y, char[][] tab){
		String number = Character.toString(tab[x][y]);
		int xBis = x;
		int yBis = y;
		while(yBis-1>=0&&Character.isDigit((tab[x][yBis-1]))) {
			yBis--;
			number = Character.toString(tab[x][yBis-1]) + number;
		}
		int startX = xBis;
		int startY = yBis;

		int xTer = x;
		int yTer = y;
		while(yBis+1<=tab[x].length&&Character.isDigit((tab[x][yBis+1]))) {
			yBis++;
			number = number + Character.toString(tab[x][yBis+1]);
		}
		int endX = xTer;
		int endY = yTer;

		return new NumberAndPositions(new Position(startX, startY), new Position(endX, endY), Integer.parseInt(number));
		//return null;
	}

}
