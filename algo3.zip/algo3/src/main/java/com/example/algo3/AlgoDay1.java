package com.example.algo3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AlgoDay1 {

    public static void main(String[]args) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get("src/main/resources/input1-part2.txt"));
        int sum = lines.stream().map(AlgoDay1::getFirstAndLast).reduce(0, (a, b) -> a + b);
        System.out.println(sum);
    }

    public static int getFirstAndLast(String line) {
        Map<String, String> maps = new HashMap<>();
        maps.put("one", "1");
        maps.put("two", "2");
        maps.put("three", "3");
        maps.put("four", "4");
        maps.put("five", "5");
        maps.put("six", "6");
        maps.put("seven", "7");
        maps.put("eight", "8");
        maps.put("nine", "9");
        Pattern pattern = Pattern.compile("(\\d{1}|one|two|three|four|five|six|seven|eight|nine)");
        Matcher matcher = pattern.matcher(line);
        String first= null;
        String last = null;
        while(matcher.find())
        {
            if (first == null) {
                first = matcher.group();

            }
            last = matcher.group();
        }
        if (last == null) {
            return Integer.parseInt(maps.getOrDefault(first, first));
        } else {
            return Integer.parseInt((maps.getOrDefault(first, first))+""+(maps.getOrDefault(last, last)));
        }
    }
}
