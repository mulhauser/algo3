package com.example.algo3;

public class NumberAndPositions {

    Position startPos;
    Position endPos;
    int number;

    public NumberAndPositions(Position startPos, Position endPos, int number) {
        this.startPos = startPos;
        this.endPos = endPos;
        this.number = number;
    }
}
